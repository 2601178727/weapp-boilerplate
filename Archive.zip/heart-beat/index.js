Component({
    properties: {
        timeInterval: {
            type: Number,
            value: 0,
            observer(newVal) {
                // 控制动画
                let animationSetting = newVal ? `animation: heartbeat ${newVal}ms alternate infinite;` : ''
                this.setData({ animationSetting })
            }
        },
        isAnimate: {
            type: Boolean,
            value: false
        },
        heartRate: {
            type: Number
        }
    },
    data: {
        animationSetting: ''
    }
})
