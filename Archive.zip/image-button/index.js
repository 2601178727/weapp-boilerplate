Component({
    options: {
        multipleSlots: true
    },
    properties: {
        openType: {
            type: String
        }
    },
    methods: {
        // 把组件的 event.detail 传递给父组件
        // 父组件通过 event.detail 进行获取
        onGetUserInfo(event) {
            this.triggerEvent('getuserinfo', event.detail, {})
        }
    }
})
